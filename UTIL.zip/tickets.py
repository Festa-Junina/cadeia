from random import randint

senhas_digitadas = []
numeros = ['1', ' 2', '3', '4', '5', '6', '7', '8', '9', '0']


def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

with open('senhas.txt', 'a') as arquivo:
    arquivo.write('insert into ticket(ticket, valido) values \n')

while len(senhas_digitadas) < 1000:
    ticket = random_with_N_digits(6)

    if ticket not in senhas_digitadas:
        senhas_digitadas.append(ticket)

        with open('senhas.txt', 'a') as arquivo:
            arquivo.write(f'({ticket},true),\n')
